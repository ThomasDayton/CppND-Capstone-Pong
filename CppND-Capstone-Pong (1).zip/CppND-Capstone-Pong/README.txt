With this Capstone Project, I have decided to take Option 2 and
recreate the classic video game Pong.

Created with help from https://austinmorlan.com/posts/pong_clone/